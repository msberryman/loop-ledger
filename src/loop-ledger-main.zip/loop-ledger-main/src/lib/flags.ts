export const flags = {
MAPS_AUTOCOMPLETE: import.meta.env.VITE_FF_MAPS_AUTOCOMPLETE === 'true',
};